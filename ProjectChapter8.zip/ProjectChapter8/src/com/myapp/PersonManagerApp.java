package com.myapp;

import com.myapp.model.Person;
import com.myapp.storage.DataStore;
import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class PersonManagerApp {
    private JFrame frame;
    private final DataStore store = new DataStore();
    private List<Person> persons = new ArrayList<>();
    private File currentFile;

    private JMenuItem saveMenu;
    private JMenuItem saveAsMenu;

    private PersonListPanel listPanel;
    private PersonDetailPanel detailPanel;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PersonManagerApp().initUI());
    }

    private void initUI() {
        applyDarkTheme();
        frame = createFrame();
        frame.setVisible(true);
    }

    private void applyDarkTheme() {
        UIManager.put("Panel.background", new Color(45, 45, 45));
        UIManager.put("Label.foreground", Color.WHITE);
        UIManager.put("MenuBar.background", new Color(30, 30, 30));
        UIManager.put("Menu.foreground", Color.WHITE);
        UIManager.put("MenuItem.background", new Color(60, 0, 0));
        UIManager.put("MenuItem.foreground", Color.WHITE);
        UIManager.put("Button.background", new Color(128, 0, 0));
        UIManager.put("Button.foreground", Color.WHITE);
        UIManager.put("TextField.background", new Color(70, 70, 70));
        UIManager.put("TextField.foreground", Color.WHITE);
        UIManager.put("ComboBox.background", new Color(70, 70, 70));
        UIManager.put("ComboBox.foreground", Color.WHITE);
        UIManager.put("List.background", new Color(55, 55, 55));
        UIManager.put("List.foreground", Color.WHITE);
        UIManager.put("List.selectionBackground", new Color(128, 0, 0));
        UIManager.put("List.selectionForeground", Color.WHITE);
    }

    private JFrame createFrame() {
        frame = new JFrame("Person Manager");
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLayout(new BorderLayout());

        listPanel = new PersonListPanel(this, persons);
        detailPanel = new PersonDetailPanel(this::onSavePerson, this::onCancelEdit);
        detailPanel.setVisible(false);

        frame.add(createMenuBar(), BorderLayout.NORTH);
        frame.add(listPanel, BorderLayout.CENTER);
        frame.add(detailPanel, BorderLayout.EAST);

        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                exitApplication();
            }
        });
        return frame;
    }

    private JMenuBar createMenuBar() {
        JMenuBar mb = new JMenuBar();

        JMenu file = new JMenu("File");
        file.add(new JMenuItem("New")).addActionListener(e -> newFile());
        file.add(new JMenuItem("Open...")).addActionListener(e -> openFile());

        saveMenu = new JMenuItem("Save");
        saveMenu.addActionListener(e -> saveFile());
        file.add(saveMenu);

        saveAsMenu = new JMenuItem("Save As...");
        saveAsMenu.addActionListener(e -> saveFileAs());
        file.add(saveAsMenu);

        file.addSeparator();
        file.add(new JMenuItem("Exit")).addActionListener(e -> exitApplication());

        JMenu help = new JMenu("Help");
        help.add(new JMenuItem("Help Contents")).addActionListener(e -> showHelp());
        help.add(new JMenuItem("About")).addActionListener(e -> showAbout());

        mb.add(file);
        mb.add(help);
        return mb;
    }

    private void newFile() {
        if (!confirmSave()) return;
        persons.clear();
        currentFile = null;
        store.markDirty();
        listPanel.refresh(persons);
    }

    private void openFile() {
        if (!confirmSave()) return;
        JFileChooser chooser = new JFileChooser();
        if (chooser.showOpenDialog(frame) == JFileChooser.APPROVE_OPTION) {
            File f = chooser.getSelectedFile();
            try {
                persons = store.load(f);
                currentFile = f;
                listPanel.refresh(persons);
            } catch (IOException | ClassNotFoundException ex) {
                showError("Load failed: " + ex.getMessage());
            }
        }
    }

    private void saveFile() {
        if (currentFile == null) {
            saveFileAs();
        } else {
            doSave(currentFile);
        }
    }

    private void saveFileAs() {
        JFileChooser chooser = new JFileChooser();
        if (chooser.showSaveDialog(frame) == JFileChooser.APPROVE_OPTION) {
            doSave(chooser.getSelectedFile());
        }
    }

    private void doSave(File f) {
        try {
            store.save(persons, f);
            currentFile = f;
        } catch (IOException ex) {
            showError("Save failed: " + ex.getMessage());
        }
    }

    private boolean confirmSave() {
        if (persons.isEmpty() || !store.isDirty()) return true;
        int choice = JOptionPane.showConfirmDialog(
            frame,
            "<html><body style='margin:0;padding:0 0 0 5px;color:red;'>Save changes before proceeding?</body></html>",
            "Confirm",
            JOptionPane.YES_NO_CANCEL_OPTION,
            JOptionPane.QUESTION_MESSAGE
        );
        if (choice == JOptionPane.CANCEL_OPTION) return false;
        if (choice == JOptionPane.YES_OPTION) saveFile();
        return true;
    }

    private void exitApplication() {
        if (confirmSave()) frame.dispose();
    }

    private void showHelp() {
        JOptionPane.showMessageDialog(frame, "Help: Use the File menu to manage persons.");
    }

    private void showAbout() {
        JOptionPane.showMessageDialog(frame, "Person Manager v1.0");
    }

    private void showError(String msg) {
        JOptionPane.showMessageDialog(frame, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void onSavePerson(Person p, boolean isNew) {
        if (isNew) {
            persons.add(p);
        }
        store.markDirty();
        listPanel.refresh(persons);
        detailPanel.setVisible(false);
        saveMenu.setEnabled(true);
        saveAsMenu.setEnabled(true);
    }

    private void onCancelEdit() {
        detailPanel.setVisible(false);
        saveMenu.setEnabled(true);
        saveAsMenu.setEnabled(true);
    }

    public void addNewPerson() {
        detailPanel.editPerson(null);
        detailPanel.setVisible(true);
        saveMenu.setEnabled(false);
        saveAsMenu.setEnabled(false);
    }

    public void editPerson(Person p) {
        detailPanel.editPerson(p);
        detailPanel.setVisible(true);
        saveMenu.setEnabled(false);
        saveAsMenu.setEnabled(false);
    }

    public void deletePerson(Person p) {
        persons.remove(p);
        store.markDirty();
        listPanel.refresh(persons);
    }
}