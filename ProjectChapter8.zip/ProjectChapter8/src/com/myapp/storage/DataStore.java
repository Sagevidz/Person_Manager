package com.myapp.storage;

import com.myapp.model.Person;
import java.io.*;
import java.util.List;

public class DataStore {
    private boolean dirty;

    public void save(List<Person> list, File file) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
            oos.writeObject(list);
            dirty = false;
        }
    }

    @SuppressWarnings("unchecked")
    public List<Person> load(File file) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            List<Person> list = (List<Person>) ois.readObject();
            dirty = false;
            return list;
        }
    }

    public boolean isDirty()   { return dirty; }
    public void markDirty()    { dirty = true; }
}