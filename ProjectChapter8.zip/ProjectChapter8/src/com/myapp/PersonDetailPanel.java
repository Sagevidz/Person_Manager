package com.myapp;

import com.myapp.model.*;
import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.util.function.BiConsumer;

public class PersonDetailPanel extends JPanel {
    private final JComboBox<String> typeBox  = new JComboBox<>(new String[]{"Person","RegisteredPerson","OCCCPerson"});
    private final JTextField firstNameField  = new JTextField(15);
    private final JTextField lastNameField   = new JTextField(15);
    private final JComboBox<Integer> monthBox = new JComboBox<>();
    private final JComboBox<Integer> dayBox   = new JComboBox<>();
    private final JComboBox<Integer> yearBox  = new JComboBox<>();
    private final JButton saveBtn             = new JButton("Save");
    private final JButton cancelBtn           = new JButton("Cancel");

    private Person editing;
    private final BiConsumer<Person, Boolean> saveCallback;
    private final Runnable cancelCallback;

    public PersonDetailPanel(BiConsumer<Person, Boolean> saveCallback, Runnable cancelCallback) {
        this.saveCallback  = saveCallback;
        this.cancelCallback = cancelCallback;
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5,5,5,5);
        c.anchor = GridBagConstraints.WEST;

        // Row 0: Type
        c.gridx=0; c.gridy=0; add(new JLabel("Type:"), c);
        c.gridx=1; add(typeBox, c);

        // Row 1: First Name
        c.gridy=1; c.gridx=0; add(new JLabel("First Name:"), c);
        c.gridx=1; add(firstNameField, c);

        // Row 2: Last Name
        c.gridy=2; c.gridx=0; add(new JLabel("Last Name:"), c);
        c.gridx=1; add(lastNameField, c);

        // Date fields
        for(int m=1;m<=12;m++) monthBox.addItem(m);
        for(int d=1;d<=31;d++) dayBox.addItem(d);
        for(int y=1900;y<=LocalDate.now().getYear();y++) yearBox.addItem(y);
        JPanel datePanel = new JPanel(new FlowLayout(FlowLayout.LEFT,5,0));
        datePanel.add(monthBox); datePanel.add(dayBox); datePanel.add(yearBox);

        c.gridy=3; c.gridx=0; add(new JLabel("Birth Date:"), c);
        c.gridx=1; add(datePanel, c);

        // Buttons
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER,10,0));
        btnPanel.add(saveBtn); btnPanel.add(cancelBtn);
        c.gridy=4; c.gridx=0; c.gridwidth=2;
        add(btnPanel, c);

        saveBtn.addActionListener(e->savePerson());
        cancelBtn.addActionListener(e->cancelCallback.run());
    }

    public void editPerson(Person p) {
        this.editing = p;
        if (p != null) {
            typeBox.setSelectedItem(p.getClass().getSimpleName());
            firstNameField.setText(p.getFirstName());
            lastNameField.setText(p.getLastName());
            OCCCDate bd = p.getBirthDate();
            monthBox.setSelectedItem(bd.getMonth());
            dayBox.setSelectedItem(bd.getDay());
            yearBox.setSelectedItem(bd.getYear());
        } else {
            typeBox.setSelectedIndex(0);
            firstNameField.setText(""); lastNameField.setText("");
            monthBox.setSelectedIndex(0); dayBox.setSelectedIndex(0); yearBox.setSelectedIndex(0);
        }
    }

    private void savePerson() {
        try {
            int m=(int)monthBox.getSelectedItem(),
                d=(int)dayBox.getSelectedItem(),
                y=(int)yearBox.getSelectedItem();
            OCCCDate date=new OCCCDate(d,m,y);
            Person p;
            boolean isNew = (editing==null);
            switch((String)typeBox.getSelectedItem()) {
                case "RegisteredPerson":
                    p = isNew? new RegisteredPerson(firstNameField.getText(), lastNameField.getText(), date)
                             : editing;
                    break;
                case "OCCCPerson":
                    p = isNew? new OCCCPerson(firstNameField.getText(), lastNameField.getText(), date)
                             : editing;
                    break;
                default:
                    p = isNew? new Person(firstNameField.getText(), lastNameField.getText(), date)
                             : editing;
            }
            p.setFirstName(firstNameField.getText());
            p.setLastName(lastNameField.getText());
            if (!isNew) p.setBirthDate(date);
            saveCallback.accept(p, isNew);
        } catch (OCCCDateException ex) {
            JOptionPane.showMessageDialog(this, "Invalid Date!", "Error", JOptionPane.ERROR_MESSAGE);
            monthBox.setSelectedIndex(0); dayBox.setSelectedIndex(0); yearBox.setSelectedIndex(0);
        }
    }
}