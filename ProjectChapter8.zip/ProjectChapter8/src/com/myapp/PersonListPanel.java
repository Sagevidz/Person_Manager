package com.myapp;

import com.myapp.model.Person;
import javax.swing.*;
import java.awt.*;
import java.util.List;

public class PersonListPanel extends JPanel {
    private final PersonManagerApp app;
    private final DefaultListModel<Person> model = new DefaultListModel<>();
    private final JList<Person> list = new JList<>(model);

    public PersonListPanel(PersonManagerApp app, List<Person> data) {
        this.app = app;
        setLayout(new BorderLayout(10, 10));
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        JButton addBtn = new JButton("Add");
        JButton editBtn = new JButton("Edit");
        JButton delBtn = new JButton("Delete");

        addBtn.addActionListener(e -> app.addNewPerson());
        editBtn.addActionListener(e -> {
            Person sel = list.getSelectedValue();
            if (sel != null) app.editPerson(sel);
        });
        delBtn.addActionListener(e -> {
            Person sel = list.getSelectedValue();
            if (sel != null) app.deletePerson(sel);
        });

        btns.add(addBtn); btns.add(editBtn); btns.add(delBtn);

        add(new JScrollPane(list), BorderLayout.CENTER);
        add(btns, BorderLayout.SOUTH);
        refresh(data);
    }

    public void refresh(List<Person> data) {
        model.clear();
        data.forEach(model::addElement);
    }
}