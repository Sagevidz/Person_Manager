package com.myapp.model;

public class OCCCPerson extends Person {
    public OCCCPerson(String fName, String lName, OCCCDate bd) {
        super(fName, lName, bd);
    }
}