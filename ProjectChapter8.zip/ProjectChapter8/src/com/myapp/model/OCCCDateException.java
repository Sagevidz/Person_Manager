package com.myapp.model;

public class OCCCDateException extends Exception {
    public OCCCDateException(String msg) {
        super(msg);
    }
}