package com.myapp.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Person implements Serializable {
    private static final long serialVersionUID = 1L;

    private String firstName;
    private String lastName;
    private OCCCDate birthDate;
    private final List<Person> children = new ArrayList<>();

    public Person(String firstName, String lastName, OCCCDate birthDate) {
        this.firstName = firstName;
        this.lastName  = lastName;
        this.birthDate = birthDate;
    }

    // Getters and setters
    public String getFirstName() { return firstName; }
    public void setFirstName(String name) { firstName = name; }

    public String getLastName() { return lastName; }
    public void setLastName(String name) { lastName = name; }

    public OCCCDate getBirthDate() { return birthDate; }
    public void setBirthDate(OCCCDate date) { birthDate = date; }

    public List<Person> getChildren() {
        return new ArrayList<>(children);
    }
    public void addChild(Person child) {
        children.add(child);
    }
    public void removeChild(Person child) {
        children.remove(child);
    }

    @Override
    public String toString() {
        return String.format("%s %s [%s]", firstName, lastName, getClass().getSimpleName());
    }
}