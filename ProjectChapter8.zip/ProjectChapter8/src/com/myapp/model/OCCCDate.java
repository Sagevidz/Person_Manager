package com.myapp.model;

import java.io.Serializable;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class OCCCDate implements Serializable {
    private static final long serialVersionUID = 1L;

    private final int day;
    private final int month;
    private final int year;

    public OCCCDate(int day, int month, int year) throws OCCCDateException {
        GregorianCalendar cal = new GregorianCalendar(year, month - 1, day);
        if (cal.get(Calendar.YEAR) != year
         || cal.get(Calendar.MONTH) != month - 1
         || cal.get(Calendar.DAY_OF_MONTH) != day) {
            throw new OCCCDateException("Invalid date: " + day + "/" + month + "/" + year);
        }
        this.day   = day;
        this.month = month;
        this.year  = year;
    }

    public int getDay()   { return day; }
    public int getMonth() { return month; }
    public int getYear()  { return year; }
}