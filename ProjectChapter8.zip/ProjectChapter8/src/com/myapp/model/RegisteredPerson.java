package com.myapp.model;

public class RegisteredPerson extends Person {
    public RegisteredPerson(String fName, String lName, OCCCDate bd) {
        super(fName, lName, bd);
    }
}