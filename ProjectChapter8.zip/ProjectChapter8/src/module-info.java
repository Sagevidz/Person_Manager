/**
 * 
 */
/**
 * 
 */
module ProjectChapter8  {
    requires java.desktop;  // Swing and AWT live here
    exports com.myapp;
    exports com.myapp.model;
    exports com.myapp.storage;
}